
function checkPassword() {
    const password = document.getElementById('passwordInput').value;
    const status = document.getElementById('statusMessage');
    if (password === 'HellfireFLN2025') {
        status.innerText = 'Zugang erlaubt! (Hier beginnt deine Webapp)';
        status.style.color = 'green';
    } else {
        status.innerText = 'Falsches Passwort!';
        status.style.color = 'red';
    }
}
